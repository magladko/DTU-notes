Course/exam contents:
- 40% Proof Assistant
- 30% Natural Deduction
- 30% Sequent Calculus
